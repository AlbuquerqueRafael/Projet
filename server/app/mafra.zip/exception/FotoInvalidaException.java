package exception;

/**
 * Created by rafael on 22/04/16.
 */
public class FotoInvalidaException extends NullPointerException {
    public FotoInvalidaException(String message) {
        super(message);
    }
}
