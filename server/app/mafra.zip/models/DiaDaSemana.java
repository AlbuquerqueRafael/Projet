package models;

/**
 * Created by Mafra on 15/04/16.
 */
public enum DiaDaSemana {
    	SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA;
}