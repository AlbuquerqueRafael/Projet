package models.enums;

/**
 * Created by Mafra on 15/04/16.
 */
public enum Status {
    PENDENTE, REJEITADO, ACEITO;
}