package models.enums;

/**
 * Created by rafael on 27/03/16.
 */
public enum TipoCarona {
    IDA, VOLTA;
}
